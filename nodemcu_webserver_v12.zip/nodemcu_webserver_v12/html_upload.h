#include <ESP8266WiFi.h>
#include <WiFiClient.h>
#include <ESP8266WiFiMulti.h>
#include <ESP8266mDNS.h>
//#include <ESP8266WebServer.h>
#include <ESPAsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include <FS.h>   // Include the SPIFFS library
extern String WEB_VERSION;
extern bool json_refresh;
extern String logmessage;
extern AsyncWebServer server;
ESP8266WiFiMulti wifiMulti;
extern int daily_jobs_count;
extern bool start_pesticide_mixing;
extern bool start_fertilizer_mixing;
extern bool start_pesticide_spary_channels;
extern int start_pesticide_spary_channels_job_id;
extern int pesticide_job_id;
extern int fertilizer_job_id;
extern String humidity;
extern String temperature;
//extern DynamicJsonDocument garden_job_schedules(7168);


File fsUploadFile;

//String getContentType(String filename);
bool handleFileRead(String path);
void handleFileUpload();
String html_head = "<html><head><title>ESP Web Server</title><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"><link rel=\"icon\" href=\"data:,\"><style>html{font-family: Helvetica; display:inline-block; margin: 0px auto; text-align: center;}h1{color: #0F3376; padding: 2vh;}p{font-size: 1.5rem;}.button{display: inline-block;background-color: #e7bd3b; border: none;border-radius: 4px; color: white; padding: 16px 40px; text-decoration: none; font-size: 30px; margin: 2px; cursor: pointer;}.button2{background-color: #4286f4;}</style></head><body><h1>ESP Web Server(" + WEB_VERSION + ")</h1>";
void handleUpload(AsyncWebServerRequest *request, String filename, size_t index, uint8_t *data, size_t len, bool final) {
  if (!SPIFFS.begin()) {
    DEBUG_SERIAL1.println("SPIFFS Mount error");
    return;
  }
  
  
  
  if (!index) {
    DEBUG_SERIAL1.println("Removing old json file file");
    SPIFFS.remove("/" + filename); 
    DEBUG_SERIAL1.printf("UploadStart: %s\n", filename.c_str());
    request->_tempFile = SPIFFS.open("/" + filename, "w");
  }
  if (len) {
    request->_tempFile.write(data, len);
    logmessage = "Writing file: " + String(filename) + " index=" + String(index) + " len=" + String(len);
    DEBUG_SERIAL1.println(logmessage);
  }
  if (final) {
    logmessage = "Upload Complete: " + String(filename) + ",size: " + String(index + len);
    request->_tempFile.close();
    DEBUG_SERIAL1.println(logmessage);
    json_refresh = true;
    request->redirect("/");
  }

}

String processor(const String& var){
  DEBUG_SERIAL1.println("step401");
  char buf[] = "DD-MM-YY:hh:mm:ss";
  DateTime now = rtc.now();
  //float t = getTemprature();
  //float h = getHumidity();
  //DEBUG_SERIAL.println("step402");
  String current_time = String(now.toString(buf));  
  String channel_status = "stopped";
  for (int i = 0; i < daily_jobs_count; i++) {
    String pin_id = "job_id_"+garden_job_schedules["schedules"]["daily"][i]["job_id"].as<String>();
    int job_id = garden_job_schedules["schedules"]["daily"][i]["job_id"];
    if(var == pin_id){
      int chennels = garden_job_schedules["schedules"]["daily"][i]["chennels"];
      int job_type = garden_job_schedules["schedules"]["daily"][i]["job_type"];
      int job_id = garden_job_schedules["schedules"]["daily"][i]["job_id"];
      if (start_pesticide_spary_channels && start_pesticide_spary_channels_job_id == job_id ){
        channel_status = "running";
        return channel_status;
      }
      else if (job_type == 2 && check_running_job_ids(job_id) ){
        channel_status = "running";
        return channel_status;
      }     
     else if (job_type == 4 ) {
      if (check_running_job_ids(job_id)){
        channel_status = "Auto|running";
      }
      else {
        channel_status = "Auto|stopped";
      }
        return channel_status;
      }      
     else if (job_type == 1 && check_running_job_ids(job_id)) {
        channel_status = "running";
        return channel_status;
      }
      else {
        return channel_status;
      }
    }
    else if (var == "SERVER_TIME" ) {
      return current_time;
    }
    else if (var == "TEMPERATURE" ) {
      DEBUG_SERIAL1.println("step302");
      //getTemprature();
      
      return temperature;
    }
    else if (var == "HUMIDITY" ) {
      DEBUG_SERIAL1.println("step303");
      //getHumidity();
      return humidity;
    }        
    
  }
  
}
void gen_index_html(){
      DEBUG_SERIAL1.println("step201");
      if (!SPIFFS.begin()) {
        DEBUG_SERIAL1.println("SPIFFS Mount error");
        return;
      }
      DEBUG_SERIAL1.println("Removing old index.html file");
      SPIFFS.remove("/index.html");
      File indexFile = SPIFFS.open("/index.html", "w");
      if (!indexFile) {
        DEBUG_SERIAL1.println("failed to open index.html for writing");
      }        
      indexFile.print("<html><head><title>ESP Web Server</title><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"><link rel=\"icon\" href=\"data:,\"><style>html{font-family: Helvetica; display:inline-block; margin: 0px auto; text-align: center;}h1{color: #0F3376; padding: 2vh;}p{font-size: 1.5rem;}.button{display: inline-block;background-color: #e7bd3b; border: none;border-radius: 4px; color: white; padding: 16px 40px; text-decoration: none; font-size: 30px; margin: 2px; cursor: pointer;}.button2{background-color: #4286f4;}</style></head><body><h1>ESP Web Server(" + WEB_VERSION + ")</h1>");
      //indexFile.print("<h2> Daily Jobs</h2>");
      indexFile.print("<h2> Server time :  %SERVER_TIME% </h2>");
      indexFile.print("<h2> Temperature|Humidity :  %TEMPERATURE% c | %HUMIDITY% % </h2>");
      //indexFile.print("<h2><a href=\"/soil_props\">Click here for Soil Sensor setup</a></h2>");
      //indexFile.print("<h2><a href=\"/adhoc\">Manual Trigger</a></h2>");
      //indexFile.print("<h2><a href=\"/weekly_jobs\">weekly Schedules</a></h2>");
      //indexFile.print("<h2> Allowed Channels 2(D4),13(D7),12(D6),14(D5)</h2>");
      indexFile.print("<table style=\"border:1px solid black;margin-left:auto;margin-right:auto;\">"); 
      for (int i = 0; i< daily_jobs_count; i++){
          int chennels = garden_job_schedules["schedules"]["daily"][i]["chennels"];
          //int job_id =  garden_job_schedules["schedules"]["daily"][i]["job_id"];
          String pin_status = "%job_id_"+garden_job_schedules["schedules"]["daily"][i]["job_id"].as<String>()+"%";
          //String pin_status = "stopped";
          String button_status = "Manage";
          indexFile.print("<tr>");
          indexFile.print("<form id=\"survey-form1\" action=\"/edit_daily_soil\" method=\"get\">");
          indexFile.print("<td><input  type=\"number\" name=\"job_id\" readonly value=" + garden_job_schedules["schedules"]["daily"][i]["job_id"].as<String>() + " size=\"5\" /></td>");
          indexFile.print("<td><input  type=\"text\" name=\"Job_Name\" readonly value=" + garden_job_schedules["schedules"]["daily"][i]["Job_Name"].as<String>() + " /></td>");
          indexFile.print("<td><input  type=\"text\" name=\"channels\" readonly  value=" + garden_job_schedules["schedules"]["daily"][i]["channels"].as<String>() + " /></td>");
          indexFile.print("<td><input  type=\"text\" name=\"pin_status\" readonly  value=" +pin_status+ "></td>");
          indexFile.print("<td><input  type=\"text\" name=\"status\" readonly value=" + garden_job_schedules["schedules"]["daily"][i]["status"].as<String>() + " /></td>");
          indexFile.print("<td><input type=\"submit\" value=\"" + button_status + "\" /></td>");
          indexFile.print("</form>");
          indexFile.print("</tr>");           
      }
      DEBUG_SERIAL1.println("step202");
        indexFile.print("</table>");
        indexFile.print("<h2> Update Webserver time </h2>");
        indexFile.print("<table style=\"border:1px solid black;margin-left:auto;margin-right:auto;\">");
        indexFile.print("<tr>");
        indexFile.print("<form id=\"survey-form1\" action=\"/update_job\" method=\"get\">");
        indexFile.print("<td><input  type=\"datetime-local\" name=\"set-time\" value= testtime /></td>");
        indexFile.print("<td><input type=\"submit\" value=\"Save\" /></td>");
        indexFile.print("</tr>");
        indexFile.print("</table>");
        indexFile.print("</body></html>");      
        indexFile.close();  
        DEBUG_SERIAL1.println("step203");
        
}
void http_methods_init() {
  server.on("/adhoc", HTTP_GET, [](AsyncWebServerRequest * request) {
    AsyncResponseStream *response = request->beginResponseStream("text/html");
    //AsyncResponseStream *response = request->beginResponseStream("text/html");
    //response->print(html_head);
    response->printf("<html><head><title>ESP Web Server</title><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"><link rel=\"icon\" href=\"data:,\"><style>html{font-family: Helvetica; display:inline-block; margin: 0px auto; text-align: center;}h1{color: #0F3376; padding: 2vh;}p{font-size: 1.5rem;}.button{display: inline-block;background-color: #e7bd3b; border: none;border-radius: 4px; color: white; padding: 16px 40px; text-decoration: none; font-size: 30px; margin: 2px; cursor: pointer;}.button2{background-color: #4286f4;}</style></head><body><h1>ESP Web Server</h1>");
    //response->print("<h2> Adhoc jobs</h2>");
    response->print("<h2><a href=\"/\">Home Page</a></h2>");
    response->print("<h2><a href=\"/restart\">ESP Restart</a></h2>");
    response->print("<h2>Channel Manual Control  </h2>");
    response->print("<table style=\"border:1px solid black;margin-left:auto;margin-right:auto;\">");
    for (int i = 0; i < daily_jobs_count; i++) {
      String channels = garden_job_schedules["schedules"]["daily"][i]["channels"];
      int job_id = garden_job_schedules["schedules"]["daily"][i]["job_id"];
      String pin_status = "stopped";
      String button_status = "start";
      /*
        if (digitalRead(channel) == 0) {
        pin_status = "running";
        button_status = "stop";
        }
      */
      if (check_running_job_ids(job_id)) {
        pin_status = "running";
        button_status = "stop";
      }
      response->print("<tr>");
      response->print("<form id=\"survey-form1\" action=\"/update_job\" method=\"get\">");
      response->print("<td><input  type=\"number\" name=\"job_id\" readonly value=" + garden_job_schedules["schedules"]["daily"][i]["job_id"].as<String>() + " size=\"5\" /></td>");
      response->print("<td><input  type=\"text\" name=\"Job_Name\" value=" + garden_job_schedules["schedules"]["daily"][i]["Job_Name"].as<String>() + " /></td>");
      response->print("<td><input  type=\"text\" name=\"channels\" readonly  value=" + garden_job_schedules["schedules"]["daily"][i]["channels"].as<String>() + " /></td>");
      response->print("<td><input  type=\"text\" name=\"pin_status\" readonly value=" +  String(pin_status) + " /></td>");
      response->print("<td><input type=\"hidden\" name=\"adhoc_trigger\" value=\"" + button_status + "\" ></td>");
      response->print("<td><input type=\"submit\" value=\"" + button_status + "\" /></td>");
      response->print("</form>");
      response->print("</tr>");
    }
    response->print("</table>");
    response->print("</body></html>");
    request->send(response);
  });
  server.on("/edit_daily_soil", HTTP_GET, [](AsyncWebServerRequest * request) {
    char buf[] = "DD-MM-YY:hh:mm:ss";
    DateTime now = rtc.now();
    int job_id ;
    String current_time = String(now.toString(buf));
    AsyncResponseStream *response = request->beginResponseStream("text/html");
    if ( request->hasParam("job_id") ) {
      job_id = request->getParam("job_id")->value().toInt();
    }
    String channel_action = "start_pin"; 
    String channels = garden_job_schedules["schedules"]["daily"][job_id]["channels"];
    int job_type = garden_job_schedules["schedules"]["daily"][job_id]["job_type"];
    DEBUG_SERIAL1.println("check_running_job_ids :"+String(check_running_job_ids(job_id))+":"+job_id+":"+job_type);
    if (check_running_job_ids(job_id) && job_type == 1 ) {
      channel_action = "stop_pin"; 
    }
    else if ( check_running_job_ids(job_id) && job_type == 4){
      channel_action = "stop_pin";
    }
    else if (check_running_job_ids(job_id) && job_type == 2 ) {
      channel_action = "stop_pin";
    }  
    else if ( job_type == 5 || job_type == 6) {
      if (start_pesticide_spary_channels) {
        channel_action = "stop_pin";
      }
      else {
        channel_action = "start_pin";
      }
    }         
    response->addHeader("Server", "ESP Async Web Server");
    response->printf("<html><head><title>ESP Web Server</title><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"><link rel=\"icon\" href=\"data:,\"><style>html{font-family: Helvetica; display:inline-block; margin: 0px auto; text-align: center;}h1{color: #0F3376; padding: 2vh;}p{font-size: 1.5rem;}.button{display: inline-block;background-color: #e7bd3b; border: none;border-radius: 4px; color: white; padding: 16px 40px; text-decoration: none; font-size: 30px; margin: 2px; cursor: pointer;}.button2{background-color: #4286f4;}</style></head><body><h1>ESP Web Server</h1>");
    response->print("<h2> Soil Sensor for Daily Jobs</h2>");
    response->print("<h2> Server time :" + current_time + "</h2>");
    response->print("<h2><a href=\"/\">Home Page</a></h2>");
    response->print("<h2><a href=\"/adhoc\">Manual Trigger</a></h2>");
    response->print("<table style=\"border:1px solid black;margin-left:auto;margin-right:auto;\">");
    response->print("<form id=\"survey-form1\" action=\"/update_job\" method=\"get\">");
    response->print("<tr>");
    response->print("<td>Job_id</td>");
    response->print("<td><input  type=\"number\" name=\"job_id\" readonly value=" + garden_job_schedules["schedules"]["daily"][job_id]["job_id"].as<String>() + " size=\"5\" /></td>");
    response->print("</tr>");
    response->print("<tr>");
    response->print("<td>Job_Name</td>");    
    response->print("<td><input  type=\"text\" name=\"Job_Name\" value=" + garden_job_schedules["schedules"]["daily"][job_id]["Job_Name"].as<String>() + " /></td>");
    response->print("</tr>");     
    response->print("<tr>");
    response->print("<td>job_type</td>");
    response->print("<td><input  type=\"number\" name=\"job_type\"  value=" + garden_job_schedules["schedules"]["daily"][job_id]["job_type"].as<String>() + " size=\"5\" /></td>");
    response->print("</tr>");   
    response->print("<tr>");
    response->print("<td>channels</td>");       
    response->print("<td><input  type=\"text\" name=\"channels\" value=" + garden_job_schedules["schedules"]["daily"][job_id]["channels"].as<String>() + " /></td>");
    response->print("</tr>");
    response->print("<tr>");
    response->print("<td>params</td>");       
    response->print("<td><input  type=\"text\" name=\"params\" value=" + garden_job_schedules["schedules"]["daily"][job_id]["params"].as<String>() + " /></td>");
    response->print("</tr>");    
    response->print("<tr>");
    response->print("<td>status</td>");       
    response->print("<td><input  type=\"text\" name=\"status\" value=" + garden_job_schedules["schedules"]["daily"][job_id]["status"].as<String>() + " /></td>");
    response->print("</tr>");         
    response->print("<tr>");   
    response->print("<td>start_cron</td>");
    response->print("<td><input  type=\"test\" name=\"start_cron\" value=" + garden_job_schedules["schedules"]["daily"][job_id]["start_cron"].as<String>() + " /></td>");
    response->print("</tr>");       
    response->print("<tr>");    
    response->print("<td>duration(sec)</td>");    
    response->print("<td><input  type=\"number\"  step=\"any\" name=\"duration\" value=" + garden_job_schedules["schedules"]["daily"][job_id]["duration"].as<String>() + " /></td>");
    response->print("</tr>");
    response->print("<tr>");      
    response->print("<td><input type=\"submit\" value=\"Save\" /></td>");
    response->print("<td><input type=\"submit\" name=\"pin_action\" value="+channel_action+" /></td>");
    response->print("</form>");
  response->print("</table></body></html>");
  request->send(response);
  });
  server.on("/restart", HTTP_GET, [](AsyncWebServerRequest * request) {
    request->send(200);
    ESP.restart();
  });  
  server.onNotFound([](AsyncWebServerRequest * request) {
    request->send(404, "text/plain", "The content you are looking for was not found.");
  });
  server.on("/upload", HTTP_GET, [](AsyncWebServerRequest * request) {
    request->send(SPIFFS, "/upload.html", String(), false);

  });

  server.on("/", HTTP_GET, [](AsyncWebServerRequest * request) {
    DEBUG_SERIAL.println("step301");
    request->send(SPIFFS, "/index.html", String(), false,processor);

  });
  server.on("/download_json", HTTP_GET, [](AsyncWebServerRequest * request) {
    DEBUG_SERIAL.println(" /Downloading json file");
    AsyncWebServerResponse *response = request->beginResponse(SPIFFS, "/schedule.json", "text/plain", true);
    request->send(response);
  });

  server.on("/clientupdate", HTTP_POST, [](AsyncWebServerRequest * request) {
    /* debug code here start here */
    //List all parameters
    int params = request->params();
    for (int i = 0; i < params; i++) {
      AsyncWebParameter* p = request->getParam(i);
      if (p->isFile()) { //p->isPost() is also true
        DEBUG_SERIAL.printf("FILE[%s]: %s, size: %u\n", p->name().c_str(), p->value().c_str(), p->size());
      } else if (p->isPost()) {
        DEBUG_SERIAL.printf("POST[%s]: %s\n", p->name().c_str(), p->value().c_str());
      } else {
        DEBUG_SERIAL.printf("GET[%s]: %s\n", p->name().c_str(), p->value().c_str());
      }
    }
    /* debug code here end here */
    if ( request->hasParam("job_id", true) ) {
      int job_id = request->getParam("job_id", true)->value().toInt();
      logmessage = "clientupdate job_id " + String(job_id);
      logging_msg(logmessage, true);
      if (job_id < daily_jobs_count ) {
        /////////
        String params = garden_job_schedules["schedules"]["daily"][job_id]["params"];
        int params_len = params.length() + 1; 
        char char_array[params_len];
        params.toCharArray(char_array, params_len);
        char *argv[10];
        int argc;
        //40,80,900,300,1,0,A0
        split(argv, &argc, char_array, ',', 0);
        if (argc != 11) {
          request->send(202); 
        } 
        /////////////
        int deep_sleep_mode = atoi(argv[11]);
        //String deep_sleep_mode = garden_job_schedules["schedules"]["daily"][job_id]["deep_sleep_mode"];
        logmessage = "deep_sleep_mode for job_id " + String(job_id) + " " + String(deep_sleep_mode);
        DEBUG_SERIAL.println(logmessage);
        logging_msg(logmessage, true);
        if ( deep_sleep_mode == 1 ) {
          request->send(200);
        }
        else {
          request->send(202);
        }
      }
      else {
        logging_msg("Invalid job_id /clientupdate post data recevied ", true);
      }

    }
    else {
      logging_msg("Invalid /clientupdate post data recevied ", true);
    }
  });

  server.on("/soilsensor", HTTP_POST, [](AsyncWebServerRequest * request) {
    /* debug code here start here */
    //List all parameters
    int params = request->params();
    for (int i = 0; i < params; i++) {
      AsyncWebParameter* p = request->getParam(i);
      if (p->isFile()) { //p->isPost() is also true
        DEBUG_SERIAL.printf("FILE[%s]: %s, size: %u\n", p->name().c_str(), p->value().c_str(), p->size());
      } else if (p->isPost()) {
        DEBUG_SERIAL.printf("POST[%s]: %s\n", p->name().c_str(), p->value().c_str());
      } else {
        DEBUG_SERIAL.printf("GET[%s]: %s\n", p->name().c_str(), p->value().c_str());
      }
    }
    /* debug code here end here */
    String clientsoilMoistureValue;
    String job_id;
    String soilhost;
    String clientversion = "null";
    String clientipaddr = "null";
    if ( request->hasParam("clientsoilMoistureValue", true) &&  request->hasParam("job_id", true) && request->hasParam("host", true) && request->hasParam("ver", true) && request->hasParam("ipaddr", true) ) {
      clientsoilMoistureValue = request->getParam("clientsoilMoistureValue", true)->value();
      DEBUG_SERIAL.println("step1");
      job_id = request->getParam("job_id", true)->value();
      DEBUG_SERIAL.println("step2");
      soilhost = request->getParam("host", true)->value();
      DEBUG_SERIAL.println("step3");
      clientversion = request->getParam("ver", true)->value();
      DEBUG_SERIAL.println("step4");
      clientipaddr = request->getParam("ipaddr", true)->value();
      DEBUG_SERIAL.println("step5");
      soil_sensor_auto_irrigation(clientsoilMoistureValue.toInt(), soilhost, job_id.toInt(), clientversion, clientipaddr);
      DEBUG_SERIAL.println("step6");
      request->send(200);
    }
    else {
      logging_msg("Invalid /soilsensor post data recevied ", true);
      DEBUG_SERIAL.println("Invalid /soilsensor post data recevied ");
      //request->send(500);
    }
    //soil_sensor_auto_irrigation(soil_moisture_l_l.toInt(),soil_moisture_h_l.toInt(),clientsoilMoistureValue.toInt());
  });
 
  server.on("/update_job", HTTP_GET, [](AsyncWebServerRequest * request) {
    DEBUG_SERIAL.println("update_job: reading params");
    bool update_arry = false;
    
    String channels;
    int job_id;
    String deep_sleep_mode;
    String start_cron;
    String stop_cron;
    String status;
    String params;
    float duration;
    int job_type;
    
    /* debug code here start here */
   
    //List all parameters
    int params1 = request->params();
    for (int i = 0; i < params1; i++) {
      AsyncWebParameter* p = request->getParam(i);
      if (p->isFile()) { //p->isPost() is also true
        DEBUG_SERIAL.printf("FILE[%s]: %s, size: %u\n", p->name().c_str(), p->value().c_str(), p->size());
      } else if (p->isPost()) {
        DEBUG_SERIAL.printf("POST[%s]: %s\n", p->name().c_str(), p->value().c_str());
      } else {
        DEBUG_SERIAL.printf("GET[%s]: %s\n", p->name().c_str(), p->value().c_str());
      }
    }
 
    /* debug code here end here */  
    if (request->hasParam("pin_action")) {
      DEBUG_SERIAL1.println("step2");
      String pin_action = request->getParam("pin_action")->value();
      String relay_channels = request->getParam("channels")->value();
      int job_id = request->getParam("job_id")->value().toInt();
      int job_type = request->getParam("job_type")->value().toInt();
      if (pin_action == "start_pin" ) {
        DEBUG_SERIAL.println("step3");
        //start_pin(relay_channel);
        //garden_job_schedules["schedules"]["daily"][job_id]["channel_Mill"] = millis();
        if (job_type == 1||job_type == 4 ) {
          channel_control(job_id,"start");
          //running_jobs_arr[job_id] = job_id ;
        }
        else if (job_type == 2) {
          start_pesticide_mixing =  true;
          pesticide_job_id = job_id;
          running_jobs_arr[job_id] = job_id;
          //channel_control(job_id,job_type,"start",false);
        }  
        else if (job_type == 5 || job_type == 6) {
          start_pesticide_spary_channels =  true;
          start_pesticide_spary_channels_job_id = job_id;
          //handle_job_type5();
        }                  
      }
      else if (pin_action == "stop_pin" ) {
        if (job_type == 1 ||job_type == 4 ) {
          channel_control(job_id,"stop");
          //running_jobs_arr[job_id] = -1;
        }
        else if (job_type == 2) {
          start_pesticide_mixing =  false;
          pesticide_job_id = job_id;
          running_jobs_arr[job_id] = -1;
          //channel_control(job_id,job_type,"stop",false);
        }     
        else if (job_type == 5 || job_type == 6) {
          start_pesticide_spary_channels =  false;
          start_pesticide_spary_channels_job_id = job_id;
          //handle_job_type5(job_id);
        }                      
      }
      request->redirect("/edit_daily_soil?job_id="+String(job_id));
      //break;
    }    
    else if (request->hasParam("set-time")) {
      //DEBUG_SERIAL.println("step5");
      String dateTime1 = request->getParam("set-time")->value();
      logging_msg("Update webserver time :", false);
      logging_msg(dateTime1, true);
      int y = dateTime1.substring(0, 4).toInt();
      int mn = dateTime1.substring(5, 7).toInt();
      int d = dateTime1.substring(8, 10).toInt();
      int h = dateTime1.substring(11, 13).toInt();
      int m = dateTime1.substring(14, 16).toInt();
      WebSerial.print(y);
      WebSerial.print("-");
      WebSerial.print(mn);
      WebSerial.print("-");
      WebSerial.print(d);
      WebSerial.print(":");
      WebSerial.print(h);
      WebSerial.print(":");
      WebSerial.println(m);
      rtc.adjust(DateTime(y, mn, d, h, m, 0));
      request->redirect("/");
      //break;
    }    
    else {
        DEBUG_SERIAL1.println("step9091");
        channels = request->getParam("channels")->value();
        job_type = request->getParam("job_type")->value().toInt();
        String Job_Name = request->getParam("Job_Name")->value();
        job_id = request->getParam("job_id")->value().toInt();
        params = request->getParam("params")->value();
        duration = request->getParam("duration")->value().toFloat();
        status = request->getParam("status")->value();
        start_cron = request->getParam("start_cron")->value();
        garden_job_schedules["schedules"]["daily"][job_id]["channels"] = channels;
        garden_job_schedules["schedules"]["daily"][job_id]["Job_Name"] = Job_Name;
        garden_job_schedules["schedules"]["daily"][job_id]["job_type"] = job_type;
        garden_job_schedules["schedules"]["daily"][job_id]["start_cron"] = start_cron;
        garden_job_schedules["schedules"]["daily"][job_id]["params"] = params;
        garden_job_schedules["schedules"]["daily"][job_id]["status"] = status;
        garden_job_schedules["schedules"]["daily"][job_id]["duration"] = duration;
        DEBUG_SERIAL1.println("step9092");
        DEBUG_SERIAL1.println(job_id);
        DEBUG_SERIAL1.println("step9093");
        //DEBUG_SERIAL.println(garden_job_schedules["schedules"]["daily"][job_id],Serial);
        serializeJson(garden_job_schedules["schedules"]["daily"][job_id], Serial);
        update_arry = true;
    }      

    //else {
    //  logmessage = "update_daily : invalid parameter received";
    //  DEBUG_SERIAL.println(logmessage);
    //}
    if (update_arry) {
      DEBUG_SERIAL.println("step7");
      logmessage = "update_daily: Updating parameter";
      DEBUG_SERIAL.println(logmessage);
      DEBUG_SERIAL.println("For loop :update daily start");
      //DEBUG_SERIAL.println("For loop :update daily arry_job_id " + String(arry_job_id));
      DEBUG_SERIAL.println("For loop :update daily job_id " + String(job_id));
      File configFile = SPIFFS.open("/schedule.json", "w");
      if (serializeJson(garden_job_schedules, configFile) == 0) {
        DEBUG_SERIAL.println(F("Failed to write to file"));
      }
      configFile.close();
      DEBUG_SERIAL.println(" - config.json saved - OK.");
      logging_msg("- config.json saved - OK.",true);
      logmessage = "update_daily: Updated parameter and generating html";
      logging_msg(logmessage,true);
      gen_index_html();
      logging_msg(logmessage,true);
      DEBUG_SERIAL.println(logmessage);
      DEBUG_SERIAL.println("For loop :update daily end");
      update_arry = false;
      request->redirect("/edit_daily_soil?job_id="+String(job_id));
      DEBUG_SERIAL.println("update_daily: redirecting to home page");
    }
    //request->send(200);
  });

  server.on("/upload", HTTP_POST, [](AsyncWebServerRequest * request) {
    request->send(200);
  }, handleUpload
  );
  server.begin();                           // Actually start the server
  DEBUG_SERIAL.println("HTTP server started");
  //##### upload_init end here ####
}
