#include "shift_register.h"
shift_register::shift_register(int serialDataPin, int clockPin, int latchPin, int oePin, int srclrPin,int size1) {
    relayOffState = 1;
    relayOnState = 0;
    _clockPin = clockPin;
    _serialDataPin = serialDataPin;
    _latchPin = latchPin;
    _oePin = oePin;
    _srclrPin = srclrPin;
    _total_pins = size1;

}
void shift_register::clearRegisters(){
  for(int i = _total_pins - 1; i >=  0; i--){
     _digitalValues[i] = relayOffState;
  }
}
void shift_register::writeRegisters(){
  digitalWrite(_latchPin, LOW);
  //Serial.println(Size * 8);
  for(int i = _total_pins - 1; i >=  0; i--){
    digitalWrite(_clockPin, LOW);
    int val = _digitalValues[i];
    digitalWrite(_serialDataPin, val);
    digitalWrite(_clockPin, HIGH);
  }
  digitalWrite(_latchPin, HIGH);
}
void shift_register::setRegisterPin(int index, int value){
  _digitalValues[index] = value;
}

void shift_register::start_pin(int pin) {
  setRegisterPin(pin, relayOnState);
  writeRegisters();
  
}
void shift_register::stop_pin(int pin) {
  //Serial.println("ShiftRegister:stop:" + String(pin));
  setRegisterPin(pin, relayOffState);
  writeRegisters();
}

int shift_register::status_pin(int pin) {
  //Serial.println("ShiftRegister:status:"+String(pin));
  if (pin >= _total_pins ) {
    return 1;
  }
  else {
    int state = _digitalValues[pin];
    return state;
  }  
}

void shift_register::setup_pin( ) {
  //Serial.println("ShiftRegister:setup_pin");
    pinMode(_clockPin, OUTPUT);
    pinMode(_serialDataPin, OUTPUT);
    pinMode(_latchPin, OUTPUT);
    // set pins low
    digitalWrite(_clockPin, LOW);
    digitalWrite(_serialDataPin, LOW);
    digitalWrite(_latchPin, LOW);
    
    clearRegisters();
    writeRegisters();
    pinMode(_oePin, OUTPUT);
    digitalWrite(_oePin, LOW);
    
    pinMode(_srclrPin, OUTPUT);
    digitalWrite(_srclrPin, LOW);
    digitalWrite(_srclrPin, HIGH);
    
    
    
}
