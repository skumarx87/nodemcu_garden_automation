#include <ArduinoJson.h>
#include <FS.h>
#include <time.h>
#include <RTClib.h>
#include <WebSerial.h>


#include "DHT.h" 
#define DHTTYPE DHT11 
#define dht_dpin 2
DHT dht(dht_dpin, DHTTYPE);
String humidity;
String temperature;
//#define shiftregister true
#define pcf8574register true
#define SPTR_SIZE   20
char *sPtr [SPTR_SIZE];
//#define DHTTYPE DHT11

/*
 * D0 16
 * D1 5 scl
 * D2 4 sda
 * D3 0 flash
 * D4 2
 * D5 14
 * D6 12
 * D7 13
 * D8 15
 */
 /*
 * job_type 1 = regular relay onOff(params (not required))
 * job_type 2 = pesticide|fertilizer mixing ( params {
 *                                  skipPesticidefill 1 or enable 0
 *                                  water_release_duration, 180s (3 minutes)
 *                                  pesticide_fill_duration, 120s (2 minutes)
 *                                  pesticide_release_duration , 60s (1 minutes)})
 * (deprecated) job_type 3 = fertilizer mixing (params
 *                                  water_release_duration, 180s (3 minutes)
 *                                  fertilizer_fill_duration, 120s (2 minutes)
 *                                  fertilizer_release_duration , 60s (1 minutes)})
 * job_type 4 = soil sensor auto Irrigation (params {
 *                                                  soil_low_value, ex 40
 *                                                  soil_up_value, ex 80
 *                                                  soil_air_value, ex 900
 *                                                  soil_water_value, ex 300
 *                                                  is_auto_irr_enable,0 or 1
 *                                                  soil_sensor_host,   0 or 1
 *                                                  soil_pin            A0 or 0 
 *                                                  soildatainterval, 1min
 *                                                  SoilautoSwitchWaithours, 460min (8 hours)
 *                                                  soilautoIrrigation_Max_start_per_Day, 2
 *                                                  deep_sleep_mode , 0 for disabled and 1 enabled})
 *                                                  
 * job_type 5 = pesticide spray (channels (pesticide_ch,ch1,ch2,ch3 etc)
 *                              (params (enable or disable temperature based spary 1 or 0,
 *                               temperature threashold ex 34}
 */

int total_pins = 8;
#if defined (shiftregister)
  int data_pin = 14;
  int clock_pin = 12;
  int latch_pin = 13; // or rclk pin
  int oe_pin = 15;
  int srclr_pin = 2;
  #include "shift_register.h"
  shift_register iocontrol(data_pin, clock_pin, latch_pin,oe_pin,srclr_pin,total_pins);
  bool is_ioport_extended_attached = true;
#elif defined (pcf8574register)
  #include "pcf8574_register.h"
  //pcf8574_register iocontrol(0x20,total_pins); //test one
  pcf8574_register iocontrol(0x38,total_pins); // live one
  bool is_ioport_extended_attached = true;
#else
  bool is_ioport_extended_attached = false;
#endif  

//RTC_DS3231 rtc;
//RTC_DS1307 rtc;
bool water_low_output = false;
// make sure to veriy the these pins before updating firmware
int p_low_water_pin = 12;
//String pesticide_motor = "3";
//String fertilizer_motor = "3";
String drip_motor = "4";
int job_type;

//unsigned long pesticidePreviousMillis = 0; 
bool start_pesticide_mixing = false;
int pesticideRelease = -1;
int pesticidefill = -1;
bool start_fillpesticide = false;
unsigned long pesticideFillPreviousMillis = 0; 
unsigned long pesticideReleasePreviousMillis = 0;
unsigned long waterReleasePreviousMillis = 0; 
int pesticide_start = -1;
int pesticide_end = -1;
int pesticide_job_id = -1;

bool start_fertilizer_mixing = false;
unsigned long soilsensor_local_preMills = 0;

int start_pesticide_spary_channels_job_id = -1;
bool is_pesticide_motor_running = false;
int previous_start_pesticide_spary_channel_index = 0;
bool start_pesticide_spary_channels = false;
bool isFirstsparychannel = false;
unsigned long time_now = 0;

unsigned long fertilizerFillPreviousMillis = 0; 
unsigned long fertilizerReleasePreviousMillis = 0;
int fertilizer_start = -1;
int fertilizer_end = -1;
int fertilizer_job_id = -1;
String WEB_VERSION  = "v12";
//int max_allowed_jobs = 15;
int running_jobs_arr[15];
/*
  int SER_Pin = 14;   //pin 14 on the 75HC595
  int RCLK_Pin = 13;  //pin 12 on the 75HC595
  int SRCLK_Pin = 12; //pin 11 on the 75HC595
*/


#define max_document_size 13168 // 7kb
//#define max_channel_mills 1800000 // 30 minutes
//#define max_channel_mills 120000 // 2min for testing
//#define max_document_size  6000// 7kb
DynamicJsonDocument garden_job_schedules(max_document_size);

int daily_jobs_count;


#define daily_jobs_no 10
#define daily_jobs_value_count 19

RTC_DS1307 rtc;

const byte relayOnState = LOW;
const byte relayOffState = HIGH;


//long soildatainterval = 35000;   // if soil data not processed for 35 sec turn off the drip line
//long SoilautoSwitchWaithours = 10800000; // 3 hours to wait and switch from auto to dripline scheduled irrigation
//long SoilautoSwitchWaithours = 120000; // 2 minutes for testing
//int soilautoIrrigation_Max_start_per_Day = 100; // For testing 100 and change to 2 while moving to live
int soilautoIrrigation_Max_start_per_day_count;
//int motor_relay_pin = 2;
//char daysOfTheWeek[7][12] = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};

bool debug_msg = true;
extern String logmessage;
//String SSiD , Pass;
//String garden_job_schedules["schedules"]["daily"][daily_jobs_no][daily_jobs_value_count];
extern bool json_refresh;
extern AsyncWebServer server;

//DHT dht(dht11_pin, DHTTYPE);

void logging_msg( String msg, bool newline,int delay_sec=0);
DateTime getTime(){
    DateTime now = rtc.now();
    return now;
}

void getTemprature() {
  float t = dht.readTemperature();
  temperature = String(t);
}

void getHumidity() {
  float h = dht.readHumidity();
  humidity = String(h);
}
bool check_running_job_ids(int job_id){
  bool return_val = false;
  for (int x=0; x<10; x=x+1){
  if (running_jobs_arr[x] == job_id) {
    DEBUG_SERIAL1.println("check_running_job_ids :"+String(running_jobs_arr[x])+":"+job_id);
    return_val = true;
    break;
   }
  }
  return return_val;
}


int check_auto_temp_enabled(int job_id) {
  int return_val = -1; // Not enabled
  String params = garden_job_schedules["schedules"]["daily"][job_id]["params"].as<String>();
  if (params.indexOf(",") == -1) {
    return return_val;
  }
  else {
    int i1 = params.indexOf(',');
    int i2 = params.indexOf(',', i1+1);
    int is_temp_sensor_enabled = params.substring(0, i1).toInt();
    int temp_threshold = params.substring(i1 + 1, i2).toInt();
    if (is_temp_sensor_enabled == 1) {
      //getTemprature();
      int current_temp  = round(temperature.toFloat());
      DEBUG_SERIAL1.println(String(job_id)+"|current temp:"+String(current_temp)+" Threshold :"+String(temp_threshold));
      if (current_temp >= temp_threshold ) {
        return_val =  1;
      }
      else {
        return_val = 0;
      }
    }
  }
  return return_val;
}
char **split(char **argv, int *argc, char *string, const char delimiter, int allowempty)
{
    *argc = 0;
    do
    {
        if(*string && (*string != delimiter || allowempty))
        {
            argv[(*argc)++] = string;
        }
        while(*string && *string != delimiter) string++;
        if(*string) *string++ = 0;
        if(!allowempty) 
            while(*string && *string == delimiter) string++;
    }while(*string);
    return argv;
}

void recvMsg(uint8_t *data, size_t len) {
  WebSerial.println("Received Data...");
  String d = "";
  for (int i = 0; i < len; i++) {
    d += char(data[i]);
  }

  if (d == "debugon") {
    debug_msg = true;
  }
  if (d == "debugoff") {
    debug_msg = false;
  }  
}
void logging_msg( String msg, bool newline,int delay_sec) {
  // WebSerial.println("Recevied msg :"+msg);
    //DateTime now = rtc.now();
    DateTime now = getTime();
    DEBUG_SERIAL1.println("Webserial:"+String(delay_sec)+"second is :"+String(now.second()));
    char buf2[] = "DD/MM/YY-hh:mm:ss";  
    //loop_log = false;
  if (debug_msg) {
    if (newline ) {
      if (delay_sec == 0) {
        WebSerial.println(String(now.toString(buf2)) + ":" + msg);
      }
      else {
        if (now.second() % delay_sec == 0) {
          WebSerial.println(String(now.toString(buf2)) + ":" + msg);
        }
      }
    }
    else {
      if (delay_sec == 0) {
        WebSerial.print(String(now.toString(buf2)) + ":" + msg);
      }
      else {
        if (now.second() % 10 == delay_sec) {
          WebSerial.println(String(now.toString(buf2)) + ":" + msg);
        }
      }
      
    }
  }
}

void start_pin ( String channels) {
  if (channels.indexOf(",") == -1) {
    DEBUG_SERIAL1.println("Starting channel :"+channels);
    iocontrol.start_pin(channels.toInt());
  }
  else {
    char char_array[channels.length() + 1];
    channels.toCharArray(char_array, channels.length() + 1);
    char *token;
    token = strtok(char_array, ",");
    while (token != NULL) {
      Serial.println(token);
      DEBUG_SERIAL1.println("Starting channel :"+String(token));
      iocontrol.start_pin(atoi(token));
      token = strtok(NULL, ",");
    }
  }
}

void stop_pin ( String channels) {
  if (channels.indexOf(",") == -1) {
    DEBUG_SERIAL1.println("Stoping channel :"+channels);
    iocontrol.stop_pin(channels.toInt());
  }
  else {
    char char_array[channels.length() + 1];
    channels.toCharArray(char_array, channels.length() + 1);
    char *token;
    token = strtok(char_array, ",");
    while (token != NULL) {
      Serial.println(token);
      DEBUG_SERIAL1.println("Stoping channel :"+String(token));
      iocontrol.stop_pin(atoi(token));
      token = strtok(NULL, ",");
    }
  }
}

int status_pin (String pin) {
  /*
  //DEBUG_SERIAL.println("-------------- status start --------------");
  //DEBUG_SERIAL.println(is_ioport_extended_attached);
  int state;
  if(is_ioport_extended_attached) {
    state = iocontrol.status_pin(pin);
  }
  else {
    state = digitalRead(pin);
  }
  //DEBUG_SERIAL.println(state);
  //DEBUG_SERIAL.println("-------------- status end --------------");
  return state;
  */
}

void monitor_pesticide_mixing(){
  DEBUG_SERIAL.println("7001");
  DEBUG_SERIAL.println(start_pesticide_mixing);
  DEBUG_SERIAL.println("7002");
  if (start_pesticide_mixing ) {
    running_jobs_arr[pesticide_job_id] = pesticide_job_id;
    // parsing arguments start
    String channels = garden_job_schedules["schedules"]["daily"][pesticide_job_id]["channels"].as<String>();
    String Job_Name = garden_job_schedules["schedules"]["daily"][pesticide_job_id]["Job_Name"].as<String>();
    DEBUG_SERIAL1.println("Job_Name :"+Job_Name+":"+channels);
    int i1 = channels.indexOf(',');
    int i2 = channels.indexOf(',', i1+1);
    String WaterRelease_relay = channels.substring(0, i1);
    String PesticdeFill_relay = channels.substring(i1 + 1, i2);
    String PesticdeRelease_relay = channels.substring(i2 + 1);
    String params = garden_job_schedules["schedules"]["daily"][pesticide_job_id]["params"];
    int params_len = params.length() + 1; 
    char char_array[params_len];
    params.toCharArray(char_array, params_len);
    char *argv[10];
    int argc;
    //40,80,900,300,1,0,A0
    split(argv, &argc, char_array, ',', 0);
    int skipPesticdeFill = atoi(argv[0]);
    int water_release_duration_sec = atoi(argv[1]);
    int pesticide_fill_duration_sec = atoi(argv[2]);
    int pesticide_release_duration_sec = atoi(argv[3]);
    unsigned long water_release_duration = water_release_duration_sec * 1000;
    unsigned long pesticide_fill_duration = pesticide_fill_duration_sec * 1000;
    unsigned long pesticide_release_duration = pesticide_release_duration_sec * 1000;
    unsigned long currentMillis = millis();
    //parsing arguments end here
    if (pesticide_start == -1 && skipPesticdeFill == 1) {
      logmessage = "Skipping"+ Job_Name+" Fill relay"; 
      logging_msg(logmessage, true);
      DEBUG_SERIAL1.println(logmessage);
      pesticide_start = 2;
      pesticide_end = 1;
    }
    //DEBUG_SERIAL.println(pesticidefill);
    //DEBUG_SERIAL.println(pesticideRelease);
    if ( pesticide_start == -1 && pesticide_end == -1) {
        logmessage = "Start Filling "+Job_Name+" Relay:"+PesticdeFill_relay; 
        logging_msg(logmessage, true);
        DEBUG_SERIAL1.println(logmessage);
        start_pin(PesticdeFill_relay);
        pesticide_end = 1;
        //DEBUG_SERIAL.println(pesticidefill);
        pesticideFillPreviousMillis = currentMillis;
    }
    else if (pesticide_start == 2 && pesticide_end == 1) {
      logmessage = "Releasing "+Job_Name+" Relay:"+PesticdeRelease_relay;
      DEBUG_SERIAL.println(logmessage);
      logging_msg(logmessage, true);
      start_pin(PesticdeRelease_relay);
      pesticide_end = 2;
      pesticideReleasePreviousMillis = currentMillis;
    }
    else if (pesticide_start == 3 && pesticide_end == 2) {
      logmessage = "Start Release Relay water:"+WaterRelease_relay;
      DEBUG_SERIAL1.println(logmessage);
      logging_msg(logmessage, true);
      start_pin(WaterRelease_relay );
      pesticide_end = 3;
      waterReleasePreviousMillis   = currentMillis;
    }    
  //DEBUG_SERIAL.println(currentMillis - pesticideFillPreviousMillis);
  /*
  DEBUG_SERIAL.println(currentMillis);
  DEBUG_SERIAL.println(pesticideFillPreviousMillis);
  DEBUG_SERIAL.println(pesticide_fill_duration);
  DEBUG_SERIAL.println(water_release_duration);
  DEBUG_SERIAL.println(pesticideReleasePreviousMillis);
  DEBUG_SERIAL.println(currentMillis - pesticideFillPreviousMillis);
  DEBUG_SERIAL.println(start_pesticide_mixing);
  DEBUG_SERIAL.println(currentMillis - pesticideReleasePreviousMillis);
  */
  if (pesticide_end == 1 && !skipPesticdeFill) {
    //DEBUG_SERIAL.println("reached here");
    if (currentMillis - pesticideFillPreviousMillis >= pesticide_fill_duration) {
        logmessage = "Stop Filling "+Job_Name+"...."+String((currentMillis - pesticideFillPreviousMillis)/1000)+"sec";
        logging_msg(logmessage, true);
        stop_pin(PesticdeFill_relay);
        DEBUG_SERIAL.println(logmessage);
        pesticide_start = 2;
      }
 }  
  else if (pesticide_end == 2) {
    //DEBUG_SERIAL.println("reached here");
    if (currentMillis - pesticideReleasePreviousMillis >= pesticide_release_duration) {
        logmessage = "Stop Releasing "+Job_Name+"  ...."+String((currentMillis - pesticideReleasePreviousMillis)/1000)+"sec";
        logging_msg(logmessage, true);
        stop_pin(PesticdeRelease_relay);
        DEBUG_SERIAL.println(logmessage);
        pesticide_start = 3;
      }
 }  
   else if (pesticide_end == 3) {
    //DEBUG_SERIAL.println("reached here");
    if (currentMillis - waterReleasePreviousMillis  >= water_release_duration) {
        logmessage = "Stop Releasing Water  ...."+String((currentMillis - waterReleasePreviousMillis)/1000)+"sec";
        logging_msg(logmessage, true);
        stop_pin(WaterRelease_relay);
        running_jobs_arr[pesticide_job_id] = -1;
        DEBUG_SERIAL1.println("Setting "+String(pesticide_job_id)+"to -1");
        DEBUG_SERIAL1.println(logmessage);
        pesticide_start = -1;
        pesticide_end = -1;
        start_pesticide_mixing = false;
        pesticide_job_id = -1;
        
        
      }
 }  
  }
  else {
    if (pesticide_start != -1 || pesticide_end != -1 ) {
      String channels = garden_job_schedules["schedules"]["daily"][pesticide_job_id]["channels"].as<String>();
      String Job_Name = garden_job_schedules["schedules"]["daily"][pesticide_job_id]["Job_Name"].as<String>();
      int i1 = channels.indexOf(',');
      int i2 = channels.indexOf(',', i1+1);
      String WaterRelease_relay = channels.substring(0, i1);
      String PesticdeFill_relay = channels.substring(i1 + 1, i2);
      String PesticdeRelease_relay = channels.substring(i2 + 1);
      String params = garden_job_schedules["schedules"]["daily"][pesticide_job_id]["params"];
      int params_len = params.length() + 1; 
      char char_array[params_len];
      params.toCharArray(char_array, params_len);
      char *argv[10];
      int argc;
      //40,80,900,300,1,0,A0
      split(argv, &argc, char_array, ',', 0);
      int skipPesticdeFill = atoi(argv[0]);
      
      DEBUG_SERIAL.println("8001");
      logmessage = "Stopping all "+Job_Name+" Filling relays" ;
      DEBUG_SERIAL1.println(logmessage);
      logging_msg(logmessage, true);
      stop_pin(PesticdeRelease_relay);
      DEBUG_SERIAL.println("8002");
      stop_pin(WaterRelease_relay);
      running_jobs_arr[pesticide_job_id] = -1;
      DEBUG_SERIAL.println("8003");
      if(skipPesticdeFill == 0) {
        DEBUG_SERIAL.println("8004");
        stop_pin(PesticdeFill_relay);
      }
      DEBUG_SERIAL.println("8005");
      pesticide_start = -1;
      pesticide_end = -1;
      pesticide_job_id = -1;
      
      DEBUG_SERIAL.println("8006");
    }
  }
}
boolean stringToken1(String timeFormat, String cronString) {
  //DEBUG_SERIAL.println("------------ stringToken start ----------------");
  //DateTime time = rtc.now();
  DateTime time = getTime();
  int matchTime;
  if (timeFormat == "minute") {
    matchTime = time.minute();
  }
  else if (timeFormat == "hour") {
    matchTime = time.hour();
  }
  else if (timeFormat == "day") {
    matchTime = time.day();
  }
  else if (timeFormat == "month") {
    matchTime = time.month();
  }  
 else if (timeFormat == "dayOfTheWeek") {
    matchTime = time.dayOfTheWeek();
  }  
  const char *delimiter =",";
  char *cronStringtoken;
  int str_len = cronString.length() + 1; 
  char char_array[str_len];
  cronString.toCharArray(char_array, str_len);
  cronStringtoken = strtok(char_array, delimiter);
  bool cronStringMatch = false;
  while (cronStringtoken  != NULL ) {
    // DEBUG_SERIAL.println( atoi(cronStringtoken) );
    if (matchTime == atoi(cronStringtoken) ){ 
      cronStringMatch = true;
      //DEBUG_SERIAL.println(cronStringtoken);
      break;
    }
      cronStringtoken = strtok(NULL, delimiter);
  } 
  //DEBUG_SERIAL.println("------------ stringToken end ----------------");
  return cronStringMatch;
}


boolean  matchCron(String cronString, DateTime time) {
    //DateTime time = rtc.now();
    boolean secMatch,minMatch,hourMatch,dayMatch,monMatch,weekMatch;
    String tempTimeString;
    String commandString;
    String weekMatchString;
    String hourMatchString;
    String minuteMatchString;
    String dayMatchString;
    String monthMatchString;
    bool everyXmin = false;
    bool everyXhour = false;
    int cronTime[6];
    cronString.trim();
    tempTimeString = cronString.substring(0,cronString.indexOf('.'));
    if(tempTimeString.indexOf("/") > 0) {
      DEBUG_SERIAL.println("everyxmin is true");
      everyXmin =  true;
      String tempTimeString1 = tempTimeString.substring(tempTimeString.indexOf('/') + 1);
      cronTime[0] = tempTimeString1.toInt();
     }
    else if (tempTimeString.equals("*")) {
      cronTime[0] = -1;
    } else {
      cronTime[0] = -2;
      minuteMatchString = tempTimeString;
    }
    cronString.trim();
    cronString = cronString.substring(cronString.indexOf('.') + 1);
    tempTimeString = cronString.substring(0,cronString.indexOf('.'));
    if(tempTimeString.indexOf("/") > 0) {
      //DEBUG_SERIAL.println("everyXhour is true");
      //DEBUG_SERIAL.println(tempTimeString);
      everyXhour =  true;
      String tempTimeString1 = tempTimeString.substring(tempTimeString.indexOf('/') + 1);
      cronTime[1] = tempTimeString1.toInt();
     }    
    else if (tempTimeString.equals("*")) {
      cronTime[1] = -1;
    } else {
      cronTime[1] = -2;
      hourMatchString = tempTimeString;
    }
    cronString = cronString.substring(cronString.indexOf('.') + 1);
    tempTimeString = cronString.substring(0,cronString.indexOf('.'));
    if (tempTimeString.equals("*")) {
      cronTime[2] = -1;
    } else {
      cronTime[2] = -2;
      dayMatchString = tempTimeString;
    }
    cronString = cronString.substring(cronString.indexOf('.') + 1);
    tempTimeString = cronString.substring(0,cronString.indexOf('.'));
    if (tempTimeString.equals("*")) {
      cronTime[3] = -1;
    } else {
      cronTime[3] = -2;
      monthMatchString = tempTimeString;
    }
    cronString = cronString.substring(cronString.indexOf('.') + 1);
    tempTimeString = cronString.substring(0,cronString.indexOf('.'));
    //DEBUG_SERIAL.println(tempTimeString);
    if (tempTimeString.equals("*")) {
      cronTime[4] = -1;
    } else {
        cronTime[4] = -2;
        weekMatchString = tempTimeString;
    }
    cronString = "";

    if (cronTime[4] == -1){
      weekMatch = true;
    } else
      {
    
        weekMatch = stringToken1("dayOfTheWeek",weekMatchString);
    }
    if (cronTime[3] == -1){
      monMatch = true;
    } else
      monMatch = stringToken1("month",monthMatchString);
    if (cronTime[2] == -1){
      dayMatch = true;
    } else
      dayMatch = stringToken1("day",dayMatchString);
    if (cronTime[1] == -1){
      hourMatch = true;
    } else if (everyXhour) { 
      if ( time.hour() % cronTime[1] == 0 ) {

        hourMatch = true;
      } else {
        hourMatch = false;
      }      
    } else
        hourMatch = stringToken1("hour",hourMatchString);

    if (cronTime[0] == -1){
      minMatch = true;
    } 
    else if (everyXmin) {
      if ( time.minute() % cronTime[0] == 0 ) {

        minMatch = true;
      } else {
        minMatch = false;
      }

    } else
      minMatch = stringToken1("minute",minuteMatchString);
      /*
     Serial.print(minMatch);
     Serial.print(':');
     Serial.print(hourMatch);
     Serial.print(':');
     Serial.print(dayMatch);
     Serial.print(':');
     Serial.print(monMatch);
     Serial.print(':');
     Serial.print(weekMatch);
     DEBUG_SERIAL.println();
     */
    if (minMatch && hourMatch && dayMatch && monMatch && weekMatch){
      return true;
    } else {
      return false;
    }
}
void channel_control(int job_id, String action) {
  String channels = garden_job_schedules["schedules"]["daily"][job_id]["channels"];
  int job_type = garden_job_schedules["schedules"]["daily"][job_id]["job_type"];
  String start_cron = garden_job_schedules["schedules"]["daily"][job_id]["start_cron"];
  DEBUG_SERIAL1.println("Method channel_control action|job_id|job_type"+action+"|"+String(job_id)+"|"+job_type);
  if (action == "start" && !check_running_job_ids(job_id)) {
    DEBUG_SERIAL1.println("111111");
    if (job_type == 1 || job_type == 4) {
      DEBUG_SERIAL1.println("111112");
      //logmessage = "Starting channel";
      //DEBUG_SERIAL1.println(logmessage);       
      if (!check_running_job_ids(job_id)) {
        DEBUG_SERIAL1.println("111113");
        int auto_temp_status=check_auto_temp_enabled(job_id);
        DEBUG_SERIAL1.println("job not running");
        DEBUG_SERIAL1.println("111114");
        if ( auto_temp_status == 0){
          DEBUG_SERIAL1.println("auto_temp_status is false");  
          running_jobs_arr[job_id] = -1;
          DEBUG_SERIAL1.println("running_jobs_arr is:"+String(job_id)+":"+String(running_jobs_arr[job_id]));
          return;
          }
        DEBUG_SERIAL1.println("Started jobs for job_id:"+job_id); 
        start_pin(channels);
        running_jobs_arr[job_id] = job_id;
        garden_job_schedules["schedules"]["daily"][job_id]["channel_Mill"] = millis();
      }
    }
      
    else {
    garden_job_schedules["schedules"]["daily"][job_id]["channel_Mill"] = millis();
    start_pin(channels);
    }
  }
  if (action == "start" && check_running_job_ids(job_id)) {
    DEBUG_SERIAL.println("It already started");
    return;
  }
  else if (action == "stop" && check_running_job_ids(job_id)) {
    DEBUG_SERIAL.println(String(job_type)+"|"+String(job_type));
    if (job_type == 1 || job_type == 4) {
      DEBUG_SERIAL.println(logmessage);
      stop_pin(channels);
      running_jobs_arr[job_id] = -1;
      garden_job_schedules["schedules"]["daily"][job_id]["channel_Mill"] = 0;
    }    
    /*
    else if (job_type == 2 ) {
      start_pesticide_mixing = false;
    }
    else if (job_type == 3 ) {
      start_fertilizer_mixing = false;
    }  
    else if (job_type == 5 ) {
      start_pesticide_spary_channels = false;
    }
    */
       
  }

  else {
    DEBUG_SERIAL.println("Invalid action type");
  }
}

void soil_sensor_auto_irrigation(int clientsoilMoistureValue, String host,int job_id, String clientversion, String ipaddr) {
 // DateTime now = rtc.now();
  String status = garden_job_schedules["schedules"]["daily"][job_id]["status"];
  bool job_status;
  if (status != "enabled" ) {
    logmessage = "Soil Irrigation is not enabled for this job " + String(job_id);
    logging_msg(logmessage, true);
    DEBUG_SERIAL1.println(logmessage);
    return;
  }
  DateTime time = getTime();
  //DEBUG_SERIAL.println(job_id);
  int job_type = garden_job_schedules["schedules"]["daily"][job_id]["job_type"];
  if (job_id >= (daily_jobs_count)) {
    //DEBUG_SERIAL.println("step9");
    logmessage = "invalid Job id from slave " + String(job_id);
    logging_msg(logmessage, true);
    DEBUG_SERIAL1.println(logmessage);
    return;
  }
  if ( job_type != 4 ) {
    logmessage = "invalid job type for job_id: " + String(job_id);
    logging_msg(logmessage, true);
    DEBUG_SERIAL1.println(logmessage);
    return;
  }
  String params = garden_job_schedules["schedules"]["daily"][job_id]["params"];
  String Job_Name = garden_job_schedules["schedules"]["daily"][job_id]["Job_Name"];
  int params_len = params.length() + 1; 
  char char_array[params_len];
  params.toCharArray(char_array, params_len);
  char *argv[10];
  int argc;
  //40,80,900,300,1,0,A0
  split(argv, &argc, char_array, ',', 0);
  if (argc != 11) {
    logmessage = "Error: Job type 4 require 11 arguments job_id: "+String(job_id);
    logging_msg(logmessage, true);
    DEBUG_SERIAL1.println(logmessage);
    return;    
  }  
  int soil_low_value = atoi(argv[0]);
  int soil_up_value = atoi(argv[1]);
  int soil_air_value = atoi(argv[2]);
  int soil_water_value = atoi(argv[3]);
  bool is_auto_irr_enable = atoi(argv[4]);
  int host_type = atoi(argv[5]);
  int SoilautoSwitchWaithours_min = atoi(argv[8]);
  long SoilautoSwitchWaithours = SoilautoSwitchWaithours_min * 60000;
  //long SoilautoSwitchWaithours = 120000; // 2 minutes for testing
  int soilautoIrrigation_Max_start_per_Day = atoi(argv[9]); // 0 localhost;1 remote host
  if (host_type == 0 && host != "localhost" ){
    logmessage = "Error:Soil data received from remote for local soil pin";
    logging_msg(logmessage,true);
    DEBUG_SERIAL1.println(logmessage);
    return;
  }
  String relaynum = garden_job_schedules["schedules"]["daily"][job_id]["channels"].as<String>();
  int soilautoIrrigation_Max_start_per_day_count = garden_job_schedules["schedules"]["daily"][job_id]["max_count"];
  long soilsensor_preMills = garden_job_schedules["schedules"]["daily"][job_id]["soilsensor_preMills"];
  logging_msg("Soildata values|Host|relay|Soilvalue :" + host + "|" + String(relaynum) + "|" + String(soil_air_value) + "|" + String(soil_water_value) + "|" + String(clientsoilMoistureValue) + "|" + clientversion + "|" + ipaddr, true);
  DEBUG_SERIAL1.println("Soil_function|Host|relay|Soilvalue :" + host + "|" + String(relaynum) + "|" + String(soil_air_value) + "|" + String(soil_water_value) + "|" + String(clientsoilMoistureValue) + "|" + clientversion + "|" + ipaddr);
  DEBUG_SERIAL.println(is_auto_irr_enable);
  if ( is_auto_irr_enable ) {
    int clientsoilMoisturePercent = map(clientsoilMoistureValue, soil_air_value, soil_water_value, 0, 100);
    unsigned long soilcurrentMillis = millis();
    long last_channel_start = soilcurrentMillis - soilsensor_preMills;
    DateTime time = getTime();
    if ( soil_air_value == 0  || soil_water_value == 0) {
      logmessage = "Error : Invalid SoilAirValue or SoilWaterValue";
      logging_msg(logmessage, true);
      DEBUG_SERIAL1.println(logmessage);
      return;
    }
    else if ( clientsoilMoisturePercent <= 0 ) {
      DEBUG_SERIAL1.println("Error :Soil Senor value not reliable.");
      logging_msg("Error :Soil Senor value not reliable.", true);
      return;
    }

    logmessage = "Soildata values|Host|relay|LL|UL|PL :" + host + "|" + String(relaynum) + "|" + String(soil_low_value) + "|" + String(soil_up_value) + "|" + String(clientsoilMoisturePercent);
    
    logging_msg(logmessage, true);
    DEBUG_SERIAL1.println(logmessage);
    if ( clientsoilMoisturePercent  <= soil_low_value )
    {
      if ( !(time.hour() >= 6  && !time.hour() <= 9   || time.hour() >= 17 && !time.hour() <= 19) ) {
        logmessage = "Irrigation allowed between 6AM to 9AM& 5PM to 7PM:" + String(time.hour()+"present time:"+String(time.hour()));
        logging_msg(logmessage, true);
        DEBUG_SERIAL1.println(logmessage);
        logmessage = "Stopping irrigation on job_id: " + String(job_id);
        logging_msg(logmessage, true);
        DEBUG_SERIAL1.println(logmessage);
        if (status_pin(relaynum) == 0 ) {
          channel_control(job_id,"stop");  
        }
        return;
      }    
      else if (soilautoIrrigation_Max_start_per_day_count > soilautoIrrigation_Max_start_per_Day ) {
        logmessage = "Soil Max start reached for job_id: "+String(job_id);
        logging_msg(logmessage,true);
        DEBUG_SERIAL1.println(logmessage);
        return;      
      }
      else if (last_channel_start < SoilautoSwitchWaithours && soilautoIrrigation_Max_start_per_day_count != 0 ) {
        logmessage = "soil_auto:last started was " + String(last_channel_start / 60000)+"m ago wait for "+String(SoilautoSwitchWaithours_min)+"m";
        logging_msg(logmessage,true);
        DEBUG_SERIAL1.println(logmessage);      
        return;
      }
      DEBUG_SERIAL.println(status_pin(relaynum));
      garden_job_schedules["schedules"]["daily"][job_id]["soilsensor_preMills"] = soilcurrentMillis; 
      soilautoIrrigation_Max_start_per_day_count = soilautoIrrigation_Max_start_per_day_count+1;
      garden_job_schedules["schedules"]["daily"][job_id]["max_count"] = soilautoIrrigation_Max_start_per_day_count;         
      if (status_pin(relaynum) == 1 ) {
        DEBUG_SERIAL1.println("Starting autoIrr and Previous count:"+String(soilautoIrrigation_Max_start_per_day_count));
        logmessage = "Soil auto irrigation Started job_id: " + String(job_id);
        DEBUG_SERIAL1.println(logmessage);
        logging_msg(logmessage, true);
        channel_control(job_id,"start");
       
      }
    }
    else if ( clientsoilMoisturePercent  >= soil_up_value ) 
    {
      logging_msg("Soil moisture reached UL,stopping job_id: " + String(job_id), true);
      DEBUG_SERIAL1.println("Soil moisture reached UL,stopping job_id: " + String(job_id));
      garden_job_schedules["schedules"]["daily"][job_id]["soilsensor_preMills"] = soilcurrentMillis; 
      if (status_pin(String(relaynum)) == 0 ) {
        channel_control(job_id,"stop");
      }
    }     
  }  
  else 
  {
    DEBUG_SERIAL1.println("Soil Irrigation or job status is not enabled for " + Job_Name);
    logging_msg("Soil Irrigation is not enabled for " + Job_Name, true);
    return;
  }
}


void garden_init() {
  // setting all values to -1
  for (int x=0; x<10; x=x+1){
    running_jobs_arr[x] = -1;
    }
    dht.begin();
    getTemprature();
    getHumidity();
    if(is_ioport_extended_attached) {
      iocontrol.setup_pin(); 
    }
    else {
      pinMode(2, OUTPUT);
      pinMode(13, OUTPUT);
      pinMode(12, OUTPUT);
      pinMode(14, OUTPUT);    
      digitalWrite(2, HIGH);
      digitalWrite(13, HIGH);
      digitalWrite(12, HIGH);
      digitalWrite(14, HIGH);      
    }
    if (! rtc.begin()) {
      DEBUG_SERIAL.println("Couldn't find RTC");
      Serial.flush();
      while (1) delay(10);
    }
  //rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));
  //rtc.adjust(DateTime(2022, 9, 20, 7, 59, 55));
  WebSerial.begin(&server);
  WebSerial.msgCallback(recvMsg);

}

void parse_json() {
  DEBUG_SERIAL.println("########## parsing json file #########");
  String path = "/schedule.json";
  if ( SPIFFS.exists(path) ) {
    File configFile = SPIFFS.open(path, "r");

    if (configFile) {
      size_t file_size = configFile.size();
      if (file_size > max_document_size) {
        Serial.print("File is higer than allowed size :");
        DEBUG_SERIAL.println(file_size);
      }
      deserializeJson(garden_job_schedules, configFile);
      daily_jobs_count = garden_job_schedules["schedules"]["daily"].size();
      DEBUG_SERIAL.println("----------- parse_json ------------" );
      DEBUG_SERIAL.println(garden_job_schedules["schedules"]["daily"][0]["Job_Name"].as<String>());
      DEBUG_SERIAL.println(garden_job_schedules["schedules"]["daily"].size());
      DEBUG_SERIAL.println(daily_jobs_count);
      //water_release_duration = garden_job_schedules["schedules"]["misc"][0]["water_release_duration"];
      DEBUG_SERIAL.println("----------- parse_json ------------" );

      for (int i = 0; i < daily_jobs_count; i++) {

        garden_job_schedules["schedules"]["daily"][i]["soilsensor_preMills"] = 0;
        garden_job_schedules["schedules"]["daily"][i]["channel_Mill"] = 0 ;
        if (garden_job_schedules["schedules"]["daily"][i]["job_type"] == 4) {
          garden_job_schedules["schedules"]["daily"][i]["max_count"] = 0;
        }    
      }

    }
    else {
      DEBUG_SERIAL.println("Unable to open Json file");
    }

  }
  else {
    DEBUG_SERIAL.println("schedule.json file does not exits");
  }
}

long readSoil(int numAve, int SOIL_PIN ) {
  int SENSOR_POWER = 5;
  pinMode( SENSOR_POWER , OUTPUT );
  //int SOIL_PIN = A0;
  long ADCValue = 0;
  for ( int i = 0; i < numAve; i++ ) {
    digitalWrite( SENSOR_POWER, HIGH );
    delay(10);    // Wait 10 milliseconds for sensor to settle.
    ADCValue += analogRead( SOIL_PIN );
    digitalWrite( SENSOR_POWER, LOW );
  }
  ADCValue = ADCValue / numAve;
  //DEBUG_SERIAL.println(ADCValue);
  return ADCValue;

}

void CronprintTime() {
  DateTime time = getTime();
  DEBUG_SERIAL1.print(time.minute(), DEC);
  DEBUG_SERIAL1.print(':');
  DEBUG_SERIAL1.print(time.hour(), DEC);
  DEBUG_SERIAL1.print(':');
  DEBUG_SERIAL1.print(time.day(), DEC);
  DEBUG_SERIAL1.print(' ');
  DEBUG_SERIAL1.print(time.month(), DEC);
  DEBUG_SERIAL1.print(':');
  DEBUG_SERIAL1.print(time.dayOfTheWeek(), DEC);
  DEBUG_SERIAL1.println();
}

void stop_running_jobs(int job_id,int job_type,String Job_Name,String channels,int channel_Mill,float duration){
  
    String start_cron = garden_job_schedules["schedules"]["daily"][job_id]["start_cron"];
    int channel_status = check_running_job_ids(job_id);
    int p_low_water_status=digitalRead(p_low_water_pin );
    if (job_type == 2 && p_low_water_status == 0 && channel_status == 0 ) {
      logmessage = Job_Name + "|" + String(job_id) + "|" + String(channels) + "|Low water from reservoir";
      logging_msg(logmessage,true);
      channel_control(job_id,"stop");
      garden_job_schedules["schedules"]["daily"][job_id]["channel_Mill"] = 0;
    }
    String pin_status = "STOPPED";
    if (channel_status == 1 ) {
      pin_status = "RUNNING";
      DEBUG_SERIAL1.println("3331");
      DEBUG_SERIAL1.println("job_id:"+String(job_id)+"mill:"+String(channel_Mill));
      if (channel_Mill > 0 ) {
        DEBUG_SERIAL1.println("3333");
        unsigned long currentMillis = millis();
        //int max_channel_mills = duration * 60000;
        int max_channel_mills = duration * 1000;
        unsigned long cal_duration = (currentMillis - channel_Mill) / 1000;
        
        DEBUG_SERIAL1.println("max_channel_mills: "+String(job_id)+"|"+String(max_channel_mills)+"|"+channel_Mill+"|"+cal_duration);
        DEBUG_SERIAL1.println("------ start ------------------");
        DEBUG_SERIAL1.println(channel_Mill);
        DEBUG_SERIAL1.println(currentMillis);
        DEBUG_SERIAL1.println(currentMillis - channel_Mill);
        DEBUG_SERIAL1.println(cal_duration);
        DEBUG_SERIAL1.println(duration);
        DEBUG_SERIAL1.println(max_channel_mills);
        DEBUG_SERIAL1.println("------ end ------------------");
        
        if (currentMillis - channel_Mill >= max_channel_mills) {
          logmessage = Job_Name + "|" + String(job_id) + "|" + String(channels) + "|Reached "+cal_duration+"sec";
          DEBUG_SERIAL1.println(logmessage);
          logging_msg(logmessage,true);
          channel_control(job_id,"stop");
          running_jobs_arr[job_id] = -1;
          garden_job_schedules["schedules"]["daily"][job_id]["channel_Mill"] = 0;
        }
      }
    }  
}
void handle_all_other_job_type(int job_id) {
  String channels = garden_job_schedules["schedules"]["daily"][job_id]["channels"];
  int channel_status = status_pin(channels);
  String pin_status =(channel_status == 1) ? "Stopped" :"Running";  
  String start_cron = garden_job_schedules["schedules"]["daily"][job_id]["start_cron"];
  if (matchCron(start_cron, getTime())) {
    //pin_status = "STARTING";
    //channel_control(channel, "start", is_depend_parent_job, parent_job_id);
    channel_control(job_id,"start");
    //logmessage = "handle_all_other_job_type: Job_id "+String(job_id) + "|" + pin_status;
    //logging_msg(logmessage, true);
    DEBUG_SERIAL.println("handle_all_other_job_type: Job_id "+String(job_id) + "|" + pin_status);
  }
  else {
    //logmessage = logmessage + "|" + pin_status;
    //logging_msg(logmessage, true);
    DEBUG_SERIAL.println("handle_all_other_job_type: Job_id "+String(job_id) + "|" + pin_status);
  }  
}

void handle_job_type4(int job_id) {
  DateTime time = getTime();
  if (time.hour() == 23 && time.minute() == 59 ){
    DEBUG_SERIAL1.println("Resetting soilautoIrrigation_Max_start_per_day_count to zero");
    // soilautoIrrigation_Max_start_per_day_count = 0; //resetting count limit every night
    garden_job_schedules["schedules"]["daily"][job_id]["max_count"] = 0;
  }
  String params = garden_job_schedules["schedules"]["daily"][job_id]["params"];
  int job_type = garden_job_schedules["schedules"]["daily"][job_id]["job_type"];
  String channels = garden_job_schedules["schedules"]["daily"][job_id]["channels"];
  //DEBUG_SERIAL.println(params);
  if (params.indexOf(",") == -1) {
      params = "";
    }
  DEBUG_SERIAL.println(params);
  int params_len = params.length() + 1; 
  char char_array[params_len];
  params.toCharArray(char_array, params_len);
  char *argv[10];
  int argc;
  //40,80,900,300,1,0,A0
  split(argv, &argc, char_array, ',', 0); 
  if (argc == 11 ) {
  String soil_sensor_host;
  int is_auto_irr_enable = atoi(argv[4]); //0 disabled ;1 enabled
  int host_type = atoi(argv[5]); // 0 localhost;1 remote host
  int soil_pin = atoi(argv[6]); // 0 localhost;1 remote host
  int soildatainterval_min = atoi(argv[7]); // 0 localhost;1 remote host
  int SoilautoSwitchWaithours_min = atoi(argv[8]); // 0 localhost;1 remote host
  int soilautoIrrigation_Max_start_per_Day = atoi(argv[9]); // 0 localhost;1 remote host
  long SoilautoSwitchWaithours = SoilautoSwitchWaithours_min * 60000;
  long soildatainterval = soildatainterval_min * 60000;
  //long soildatainterval = 35000; //35 sec for testing
  //long SoilautoSwitchWaithours = 120000; // 2 minutes for testing
  unsigned long soilcurrentMillis = millis();
  if (host_type == 0 ) {
    soil_sensor_host = "localhost";
  }
  else {
    soil_sensor_host = "remote";
  }
  long soilsensor_preMills = garden_job_schedules["schedules"]["daily"][job_id]["soilsensor_preMills"];
  String Job_Name = garden_job_schedules["schedules"]["daily"][job_id]["Job_Name"];
  long cal_soildatainterval = soilcurrentMillis - soilsensor_local_preMills;
  if ( is_auto_irr_enable && soil_sensor_host == "localhost") {
    if (  cal_soildatainterval >= soildatainterval ) {
      soilsensor_local_preMills = soilcurrentMillis;
      //garden_job_schedules["schedules"]["daily"][job_id]["soilsensor_preMills"] = soilcurrentMillis;
      DEBUG_SERIAL1.println("daily Job Local auto irrigation enabled job_id :" + String(job_id));
      int numMeasure = 5;
      String clientsoilMoistureValue = String( readSoil( numMeasure, soil_pin ) );
      //String clientsoilMoistureValue = "650"; //testing
      DEBUG_SERIAL1.println("Soil moisture interval read from Localhost: "+String(cal_soildatainterval)+"ms");
      DEBUG_SERIAL1.println("Soil moisture value from Localhost: "+clientsoilMoistureValue);
      soil_sensor_auto_irrigation(clientsoilMoistureValue.toInt(), soil_sensor_host, job_id, WEB_VERSION, "localhost");       
    }
  }
  else if ( is_auto_irr_enable && soil_sensor_host == "remote" ) {
    DEBUG_SERIAL1.println(soildatainterval);
    DEBUG_SERIAL1.println(cal_soildatainterval);
    DEBUG_SERIAL1.println(SoilautoSwitchWaithours);
    DEBUG_SERIAL1.println(soilcurrentMillis - soilsensor_preMills);
    unsigned long soilchannel_last_start = soilcurrentMillis - soilsensor_preMills;
    if (soilchannel_last_start >= SoilautoSwitchWaithours ) {
        logmessage = "Auto_irr: job_id " + String(job_id) + " not processed for more than "+String((soilcurrentMillis - soilsensor_preMills) / 3600000)+"hr";
        logging_msg(logmessage, true,10);
        DEBUG_SERIAL1.println(logmessage);
        DEBUG_SERIAL1.println("Auto_irr: Switching back job_id " + String(job_id) + "to Scheduled Irrigation");
        String start_cron = garden_job_schedules["schedules"]["daily"][job_id]["start_cron"];
        DEBUG_SERIAL1.println(start_cron);
        if (matchCron(start_cron, getTime())) {
          DEBUG_SERIAL1.println("Starting Schedule job");
          garden_job_schedules["schedules"]["daily"][job_id]["soilsensor_preMills"] = soilcurrentMillis; 
          channel_control(job_id,"start");
        }      
    }
    else if (cal_soildatainterval >= soildatainterval ) { 
        soilsensor_local_preMills = soilcurrentMillis;
        logmessage = "Auto_irr: job_id " + String(job_id) + " was not processed for "+String((soilcurrentMillis - soilsensor_preMills) / 60000)+ "min";
        logging_msg(logmessage, true);
        DEBUG_SERIAL1.println(logmessage);
      }    
    }  
  }
  else {
    DEBUG_SERIAL1.println("Invalid parameter for job_id with type 4: "+String(job_id));
  }
}

void handle_job_type5(){
    String channel;
    String channels;
    String pesticide_motor;
    int job_id = start_pesticide_spary_channels_job_id;
    
    if (start_pesticide_spary_channels) {
      int auto_temp_status=check_auto_temp_enabled(job_id);
      if ( auto_temp_status == 0){
        start_pesticide_spary_channels = false;
        return;
        }
    channels = garden_job_schedules["schedules"]["daily"][job_id]["channels"].as<String>();
    float duration = garden_job_schedules["schedules"]["daily"][job_id]["duration"];   
    int d_seconds = duration * 1000;    
    char *argv[11];
    int argc;
    int channels_len = channels.length() + 1;
    char char_array[channels_len];
    channels.toCharArray(char_array, channels_len);
    if (channels.indexOf(",") == -1) {
        //channels = "";
        argc = 1;
        argv[0] = char_array;
      } 
      else {
        split(argv, &argc, char_array, ',', 0);
        pesticide_motor = argv[0];
      }
    if (!is_pesticide_motor_running) {
      previous_start_pesticide_spary_channel_index = 1; //ignore first argurment which is assigned to motor
      channel = argv[previous_start_pesticide_spary_channel_index];
      DEBUG_SERIAL1.println("index is: "+String(previous_start_pesticide_spary_channel_index));
      logmessage = "Starting First channel :"+String(channel);
      logging_msg(logmessage,true);
      DEBUG_SERIAL1.println(logmessage);      
      DEBUG_SERIAL1.println("Argument count :"+String(argc));
      start_pin(channel);
      logmessage = "Starting Pesticide_motor :"+String(pesticide_motor);
      logging_msg(logmessage,true);
      DEBUG_SERIAL1.println(logmessage);        
      start_pin(String(pesticide_motor));
      previous_start_pesticide_spary_channel_index++;
      is_pesticide_motor_running = true;
      time_now = millis();
      DEBUG_SERIAL1.println(time_now);
    }
    else if ( previous_start_pesticide_spary_channel_index < argc && argc > 0 && millis() >= time_now + d_seconds) {
      DEBUG_SERIAL1.println("step4");
      //DEBUG_SERIAL1.println((millis() - time_now) / 1000);
      DEBUG_SERIAL1.println("argument count is "+String(argc));
      DEBUG_SERIAL1.println((millis() - time_now) / 1000);
      DEBUG_SERIAL1.println("previous_start_pesticide_spary_channel_index: "+String(previous_start_pesticide_spary_channel_index));
      channel = argv[previous_start_pesticide_spary_channel_index];
      logmessage = "Starting channel :"+String(channel);
      logging_msg(logmessage,true);
      DEBUG_SERIAL1.println(logmessage);
      start_pin(channel);
      channel = argv[previous_start_pesticide_spary_channel_index - 1];  
      //channel = atoi(argv[previous_start_pesticide_spary_channel_index - 1]);
      DEBUG_SERIAL1.println("Stopping previous channel :"+String(channel));
      stop_pin(channel);
      int total_duration = ((millis() - time_now) / 1000);
      logmessage = "Total duration channel:"+String(channel)+":"+String(total_duration)+"sec";
      logging_msg(logmessage, true);
      DEBUG_SERIAL1.println(logmessage);     
      previous_start_pesticide_spary_channel_index++;
      DEBUG_SERIAL1.println(millis() >= time_now);
      time_now = millis();
      //previous_start_pesticide_spary_channel_index
    } 
    else if (previous_start_pesticide_spary_channel_index == argc && argc > 0 && millis() >= time_now + d_seconds ) {
      DEBUG_SERIAL1.println("step5");
      DEBUG_SERIAL1.println("argument count is "+String(argc));
      DEBUG_SERIAL1.println(millis());
      DEBUG_SERIAL1.println("Stopping pesticide_motor :"+String(pesticide_motor));
      stop_pin(String(pesticide_motor));
      channel = argv[previous_start_pesticide_spary_channel_index - 1];         
      DEBUG_SERIAL1.println("Stopping channel :"+String(channel));
      stop_pin(channel);
      int total_duration = ((millis() - time_now) / 1000);
      logmessage = "Total duration channel:"+String(channel)+":"+String(total_duration)+"sec";
      logging_msg(logmessage, true);
      DEBUG_SERIAL1.println(logmessage);
      is_pesticide_motor_running = false;
      previous_start_pesticide_spary_channel_index = -1;
      start_pesticide_spary_channels_job_id = -1;
      start_pesticide_spary_channels = false;
      running_jobs_arr[job_id] = -1;
    }
    else if ( argc == 0 && millis() >= time_now + d_seconds ) {
      DEBUG_SERIAL1.println("step2000");
      int total_duration = ((millis() - time_now) / 1000);
      logmessage = "Total duration channel:"+String(channels)+":"+String(total_duration)+"sec";
      logging_msg(logmessage, true);      
      DEBUG_SERIAL1.println("Stopping pesticide_motor :"+String(channels));
      DEBUG_SERIAL1.println(logmessage);
      stop_pin(String(pesticide_motor));
      channel = garden_job_schedules["schedules"]["daily"][job_id]["channels"].as<String>();
      stop_pin(channel);  
      is_pesticide_motor_running = false;
      previous_start_pesticide_spary_channel_index = -1;
      start_pesticide_spary_channels_job_id = -1;
      start_pesticide_spary_channels = false;      
      running_jobs_arr[job_id] = -1;
    }    
  }

  else {
      if (previous_start_pesticide_spary_channel_index != -1 && is_pesticide_motor_running ) {
        int job_id = start_pesticide_spary_channels_job_id;
        String params = garden_job_schedules["schedules"]["daily"][job_id]["params"]; 
        float duration = garden_job_schedules["schedules"]["daily"][job_id]["duration"];      
        DEBUG_SERIAL1.println("step6");
        DEBUG_SERIAL1.println("Stopping channel: pesticide_motor");
        stop_pin(String(pesticide_motor));
        channels = garden_job_schedules["schedules"]["daily"][job_id]["channels"].as<String>();
        DEBUG_SERIAL1.println("Stopping channel:"+ channels);
        stop_pin(channels);
        /*
        for (int k = 0 ; k < argc; k++) { 
          String channels = argv[k];
          DEBUG_SERIAL1.println("Stopping channel:"+String(channels));
          stop_pin(channels);
        }
        */
        start_pesticide_spary_channels_job_id = -1;
        time_now = 0;
        is_pesticide_motor_running = false;
        previous_start_pesticide_spary_channel_index = -1;   
        running_jobs_arr[job_id] = -1;   
    }
  }
}

bool check_duration_less_than_minutes(int duration) {
  bool return_val = false;
  if (duration >= 60 ) {
    return_val = true;
  }
  else {
    DateTime time = getTime();
    if (time.second() == 59 || time.second() == 60 ){
      return_val = true;
    }
  }
  return return_val;
}
/*
void handle_jobtype1(int job_id) {
for (int x=0; x<10; x=x+1){
  int job_id = running_jobs_arr[x];
  int job_type = garden_job_schedules["schedules"]["daily"][job_id]["job_type"];
}
}

void monitoring_running_jobs() {
  for (int x=0; x<10; x=x+1){
    int job_id = garden_job_schedules["schedules"]["daily"][x]["job_id"];
    if ( x == job_id ) {
      int job_type = garden_job_schedules["schedules"]["daily"][x]["job_type"];
      if ( job_type == 1 ) {
        handle_jobtype1(job_id);
    }
  }
  
}
*/
void run_daily_jobs() {
  CronprintTime();
  DateTime time = getTime();
  if (time.second() % 10 == 0) {
    getHumidity();
    getTemprature();
    DEBUG_SERIAL1.println("Temperature is :"+temperature);
    DEBUG_SERIAL1.println("humidity is :"+humidity);
  }
  for (int i = 0; i < daily_jobs_count; i++) {
    String channels = garden_job_schedules["schedules"]["daily"][i]["channels"].as<String>();
    int job_id = garden_job_schedules["schedules"]["daily"][i]["job_id"];
    String status = garden_job_schedules["schedules"]["daily"][i]["status"];
    String Job_Name = garden_job_schedules["schedules"]["daily"][i]["Job_Name"];
    String start_cron = garden_job_schedules["schedules"]["daily"][i]["start_cron"];
    float duration = garden_job_schedules["schedules"]["daily"][i]["duration"];
    int channel_Mill = garden_job_schedules["schedules"]["daily"][i]["channel_Mill"];
    int job_type = garden_job_schedules["schedules"]["daily"][i]["job_type"];
    long soilsensor_preMills = garden_job_schedules["schedules"]["daily"][i]["soilsensor_preMills"];
    int channel_status = check_running_job_ids(job_id);
    String pin_status =(channel_status == 1) ? "Stopped" :"Running";
    logmessage = Job_Name + "|" + String(job_id) + "|" + start_cron + "|" + duration  + "|" + channels + "|" + status;
    if (status == "enabled" ) {
      stop_running_jobs(job_id,job_type,Job_Name,channels,channel_Mill,duration);
      if ( job_type == 1 ) {
        if (matchCron(start_cron, getTime()) && !check_running_job_ids(job_id) && check_duration_less_than_minutes(duration)) { 
          DEBUG_SERIAL1.println("starting job_id:"+String(job_id));
          //running_jobs_arr[job_id] = job_id;
          channel_control(job_id,"start");
          
        }
        //handle_job_type1(job_id);
      }
      else if (job_type == 2 ) {
        if (matchCron(start_cron, getTime()) && !check_running_job_ids(job_id) && check_duration_less_than_minutes(duration)) { 
          DEBUG_SERIAL1.println("starting "+Job_Name+" starting");
          start_pesticide_mixing = true;
          //running_jobs_arr[job_id] = job_id;
          pesticide_job_id = job_id;
        }
      }
      else if (job_type == 4 ) {
        handle_job_type4(job_id);
      }  
      else if (job_type == 5 ) {
        if (matchCron(start_cron, getTime()) && !check_running_job_ids(job_id) && check_duration_less_than_minutes(duration)) { 
          start_pesticide_spary_channels = true;
          start_pesticide_spary_channels_job_id = job_id;
          //handle_job_type5(job_id,true);
        }
      }         
      /*
      else if (job_type == 6 ) {
        if (matchCron(start_cron, getTime()) && check_running_job_ids(job_id)) {
          if (is_temp_sensor_enabled ) {
            int current_temp  = round(temperature.toFloat());
            DEBUG_SERIAL1.println("Temperature based spary enabled");
            DEBUG_SERIAL1.println("current temp:"+String(current_temp)+" Threshold :"+String(temp_threshold));
            if (current_temp >= temp_threshold ) {
              DEBUG_SERIAL1.println("Temperature based spary triggred");
              //DEBUG_SERIAL1.println("current temp:"+String(current_temp)+" Threshold :"+String(temp_threshold));
              start_pesticide_spary_channels = true;
              start_pesticide_spary_channels_job_id = job_id;
              //handle_job_type5(true);
            }
          }
          else {
            DEBUG_SERIAL1.println("Temperature based spary disabled");
            start_pesticide_spary_channels = true;
            start_pesticide_spary_channels_job_id = job_id;
          }
        }
       }     
       */
      }
    else {
      //logmessage = "daily Job :" + Job_Name + " is disabled :" + job_id;
      DEBUG_SERIAL.println("daily Job :" + Job_Name + " is disabled :" + String(job_id));
    }    
    }
    
}
