#include "pcf8574_register.h"

pcf8574_register::pcf8574_register(const uint8_t i2c_addr,int total_pins) {
    //pcf8574s.pcf8574(0x38);
    pcf8574s = new PCF8574(i2c_addr);
    relayOnState = 0;
    relayOffState = 1;
    _total_pins = total_pins;
}

void pcf8574_register::start_pin(int pin){
  //Serial.println("pcf8574Register:start:"+String(pin));
  pcf8574s->digitalWrite(pin, relayOnState);
}

void pcf8574_register::stop_pin(int pin){
  //Serial.println("pcf8574Register:stop:"+String(pin));
  pcf8574s->digitalWrite(pin, relayOffState);
}
int pcf8574_register::status_pin(int pin){
  //Serial.println("pcf8574Register:status:"+String(pin));
  if (pin >= _total_pins ) {
    return 1;
  }
  else {
    int state = pcf8574s->digitalRead(pin);
    return state;
  }
}
void pcf8574_register::setup_pin(){
   for(int i=0;i<_total_pins ;i++) {
      pcf8574s->pinMode(i, OUTPUT);
      pcf8574s->digitalWrite(i, HIGH);
    }           
    pcf8574s->begin();
}
