#pragma once
#ifndef pcf8574_register_h
#define pcf8574_register_h
#include <Arduino.h>
#include "PCF8574.h"

class pcf8574_register {
  private:
    int relayOffState;
    int relayOnState;
    int _total_pins;
    //uint8_t i2c_addr;
    PCF8574 *pcf8574s;
  public:
    
    pcf8574_register(const uint8_t i2c_addr,int total_pins);
    void start_pin(int pin);
    void stop_pin(int pin);
    int status_pin(int pin);
    void setup_pin();
};
#endif
