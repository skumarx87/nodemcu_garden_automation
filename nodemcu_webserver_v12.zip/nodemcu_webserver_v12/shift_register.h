#pragma once
#ifndef shift_register_h
#define shift_register_h
#include <Arduino.h>


class shift_register {
  private:
    int _clockPin;
    int _serialDataPin;
    int _latchPin;
    int _oePin;
    int _srclrPin;
    int  _digitalValues[7];
    int relayOffState;
    int relayOnState;
    int _total_pins;

  public:
    shift_register(int serialDataPin, int clockPin, int latchPin,int oePin, int srclrPin,int size1);
    void start_pin(int pin);
    void stop_pin(int pin);
    int status_pin(int pin);
    void setup_pin();
    void clearRegisters();
    void writeRegisters();
    void setRegisterPin(int index, int value);    
};
#endif
